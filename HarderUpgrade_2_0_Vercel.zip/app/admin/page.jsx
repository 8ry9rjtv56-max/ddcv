
export default function Admin(){
return <main>
<h1>🛠 Harder Upgrade Admin</h1>
<p>Add skins, manage users and chances here.</p>
</main>
}
