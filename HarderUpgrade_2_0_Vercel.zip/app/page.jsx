
'use client';
import {useState} from 'react';

const skins=[
 {name:'Neon Blue',rarity:'Rare'},
 {name:'Shadow',rarity:'Epic'},
 {name:'Dragon Fire',rarity:'Legendary'},
 {name:'Cyber Gold',rarity:'Mythic'}
];

export default function Home(){
 const [drop,setDrop]=useState(null);
 function spin(){
  const s=skins[Math.floor(Math.random()*skins.length)];
  setDrop(s);
 }
 return <main>
  <h1>⚡ Harder Upgrade</h1>
  <section>
   <h2>🎰 Upgrade Roulette</h2>
   <div className="case">🔒</div>
   <button onClick={spin}>OPEN CASE</button>
   {drop&&<h2>✨ {drop.name} - {drop.rarity}</h2>}
  </section>
  <section>
   <h2>👤 Profile</h2>
   <p>Level: 1</p>
   <p>Starter skins: Neon Blue, Shadow</p>
  </section>
 </main>
}
