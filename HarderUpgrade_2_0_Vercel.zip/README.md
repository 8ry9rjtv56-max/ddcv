
# Harder Upgrade 2.0

Vercel-ready starter.

Features included:
- Next.js structure
- Supabase configuration placeholder
- Auth pages
- Profile page
- Roulette component
- Skins system foundation
- Admin route foundation

Setup:
1. npm install
2. Add .env.local:
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
3. npm run dev
4. Deploy to Vercel
